document.addEventListener("deviceready", init, false);

var x, y, z, posX, posY;


function init() {
    if(window.DeviceOrientationEvent){
        window.addEventListener("deviceorientation", handleOrientation)
    } else{
        alert("no luck")
    }

function handleOrientation(event){
    
    z = event.alpha
    y = event.beta
    x = event.gamma
    
    posX += x;
    posY += y;
    
//    posX = map(x, -180, 180, 90, -180)
//    posy = map(y, -90, 90, -90, -180)
    
    $("#alpha").html(z)
    $("#beta").html(y)
    $("#gamma").html(x)
}
    
}

function setup(){
    var cnv = createCanvas(window.innerWidth, window.innerHeight, WEBGL)
    cnv.parent("myCanvas")
    
    posX = 0;
    posY = 0;
    angleMode(DEGREES);
}

function draw(){
    
    push();
    fill(255,50,100)
    rotateX(posX*1)
    rotateY(posY*1)
    triangle(30, 75, 58, posX, posY,z);
    pop();
    
    push();
    fill(25,250,255)
    rotateX(posX*1)
    rotateY(posY*1)
    rect(100,100,posY,posX)
    pop();
    
}